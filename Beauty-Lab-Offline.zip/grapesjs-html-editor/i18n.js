(function initBeautyLabI18n(global) {
  "use strict";

  const STORAGE_KEY = "edward-beauty-lab-language";
  const ATTRIBUTES = ["title", "aria-label", "placeholder"];
  const english = {
    "PNG 导出保留当前画面，支持资源缺失提示、尺寸限制、取消和重复点击保护。": "PNG export preserves the current view and includes missing-resource warnings, size limits, cancellation and duplicate-click protection.",
    "同步更新中英文指南、离线包与网站缓存。": "Updated the bilingual guide, offline package and website cache.",
    "导出 PNG": "Export PNG",
    "下载 PNG": "Download PNG",
    "导出范围": "Export range",
    "当前画布": "Current canvas",
    "完整长图": "Full document",
    "清晰度": "Resolution",
    "1 倍": "1×",
    "2 倍": "2×",
    "图片尺寸": "Image dimensions",
    "当前画布导出当前滚动位置；长图包含文档可滚动内容，不自动翻页。复杂 CSS 效果可能存在差异。": "Current canvas captures the current scroll position. Full document includes scrollable content without advancing slides. Complex CSS effects may differ.",
    "仍然导出，允许上述内容缺失": "Export anyway, allowing the missing content listed above",
    "正在生成 PNG…": "Generating PNG…",
    "PNG 已导出": "PNG exported",
    "PNG 导出正在进行。": "A PNG export is already in progress.",
    "PNG 导出超时，请重试。": "PNG export timed out. Try again.",
    "PNG 生成失败，请重试。": "PNG generation failed. Try again.",
    "页面尚未就绪，请稍后重试。": "The page is not ready. Try again shortly.",
    "图片尺寸超限，请选择 1 倍或当前画布。": "Image too large. Choose 1× or Current canvas.",
    "部分内容无法完整导出。勾选下方选项后可继续。": "Some content cannot be captured fully. Select the option below to continue.",
    "图片或背景无法读取": "Image or background could not be read",
    "Canvas 无法读取": "Canvas could not be read",
    "嵌入页面无法导出": "Embedded pages cannot be exported",
    "视频无法导出": "Video cannot be exported",
    "部分字体未能载入": "Some fonts did not load",
    "滤镜效果可能无法完整还原": "Filter effects may not render fully",
    "文字输入保护与 PNG 导出": "Protected text input and PNG export",
    "修复编辑文字时空格等按键触发原页面快捷键的问题，支持中文输入法。": "Fixed text input triggering original page shortcuts, including Space; supports IME composition.",
    "新增当前画布与完整长图 PNG 导出，支持 1 倍和 2 倍清晰度。": "Added current-canvas and full-document PNG export at 1× and 2× resolution.",
    "打开或恢复文档时默认收起图层，可从工具栏随时展开。": "Layers start collapsed when opening or restoring a document and can be expanded from the toolbar.",
    "文件已切换，请重试当前操作。": "The file has changed. Retry the current action.",
    "显示比例、可靠保存与对象工具": "Zoom, reliable saving and object tools",
    "编辑与预览支持 1%–200% 显示比例，页面尺寸独立设置并可恢复。": "Edit and Preview support 1%-200% zoom with separate, restorable page dimensions.",
    "新增本地自动草稿和最近 20 个历史版本，保存失败时保留当前修改。": "Local autosave keeps 20 recent versions and preserves current edits when saving fails.",
    "修复内联样式优先级、打印样式和动态内容重复导出的问题。": "Fixed inline style priority, print styles and duplicate dynamic content in exports.",
    "新增保留交互与静态画面导出，Canvas 静态画面可转为图片。": "Added interactive and static exports, with canvas snapshots converted to images.",
    "新增文字框、形状、锁定、隐藏、复制格式和图片取景工具。": "Added text boxes, shapes, locking, hiding, format copying and image framing.",
    "本地草稿": "Local drafts",
    "草稿文件": "Draft files",
    "历史版本": "Version history",
    "刷新草稿": "Refresh drafts",
    "恢复此版本": "Restore version",
    "删除草稿": "Delete draft",
    "暂无本地草稿": "No local drafts",
    "暂无历史版本": "No version history",
    "版本": "Version",
    "最新": "Latest",
    "个草稿": "drafts",
    "个版本": "versions",
    "已恢复草稿": "Draft restored",
    "已删除草稿": "Draft deleted",
    "删除这个草稿及其全部历史版本？": "Delete this draft and all its versions?",
    "此版本已不存在，请刷新草稿列表。": "This version no longer exists. Refresh the draft list.",
    "本地空间不足，草稿未保存。请导出 HTML 或删除旧草稿。": "Local storage is full. Export HTML or delete older drafts.",
    "此浏览器无法使用本地草稿，请及时导出 HTML。": "Local drafts are unavailable in this browser. Export HTML to keep your work.",
    "草稿数据无法保存，请导出 HTML。": "The draft could not be saved. Export HTML to keep your work.",
    "草稿未保存，请稍后重试或导出 HTML。": "Draft not saved. Try again or export HTML.",
    "正在保存草稿": "Saving draft",
    "草稿已保存": "Draft saved",
    "草稿保存失败": "Draft save failed",
    "当前草稿未保存，未切换文件。": "The current draft was not saved. The file was not switched.",
    "预览同步未返回有效内容，请重试。": "Preview sync returned no usable content. Try again.",
    "导出内容": "Export content",
    "保留交互": "Keep interactions",
    "静态画面（停用脚本）": "Static view (scripts off)",
    "静态画面": "Static view",
    "静态导出有未能保留的内容": "Some content cannot be included in the static export",
    "脚本与按钮交互将停用；Canvas 将转为图片，嵌入页面无法转换。": "Scripts and button interactions will be disabled. Canvas becomes an image; embedded pages cannot be converted.",
    "编辑记录尚未同步，请稍后重试。": "Edits have not synced yet. Try again shortly.",
    "页面仍在恢复动态内容，请等待载入完成。": "Dynamic content is still being restored. Wait for loading to finish.",
    "已保存此前版本，最新修改仍未保存": "The previous version was saved. Newer edits remain unsaved.",
    "已创建静态副本，交互版本保留在草稿中": "Static copy created. The interactive version remains in drafts.",
    "创建静态副本？": "Create a static copy?",
    "副本保留当前画面，脚本和按钮交互将停用。原交互版本保留在本地草稿中。": "The copy keeps the current view with scripts and button interactions disabled. The interactive original remains in local drafts.",
    "对象操作": "Object actions",
    "插入对象": "Insert object",
    "锁定对象": "Lock object",
    "解锁对象": "Unlock object",
    "隐藏对象": "Hide object",
    "显示对象": "Show object",
    "复制格式": "Copy format",
    "应用格式": "Apply format",
    "文字框": "Text box",
    "矩形": "Rectangle",
    "椭圆": "Ellipse",
    "图片取景": "Image framing",
    "原始": "Original",
    "适应": "Fit",
    "填充": "Fill",
    "自定义": "Custom",
    "左上": "Top left",
    "上方": "Top",
    "右上": "Top right",
    "左侧": "Left",
    "右侧": "Right",
    "左下": "Bottom left",
    "下方": "Bottom",
    "右下": "Bottom right",
    "取景高度 (px)": "Frame height (px)",
    "取景位置": "Frame position",
    "新文字": "New text",
    "格式已复制": "Format copied",
    "本地 HTML 美化工坊": "Local HTML Design Workshop",
    "尚未打开 HTML": "No HTML opened",
    "等待载入": "Waiting to load",
    "正在准备编辑器…": "Preparing editor…",
    "文件名": "File name",
    "点击修改导出文件名": "Click to edit the export file name",
    "输入导出文件名": "Enter an export file name",
    "文件名不能为空": "File name cannot be empty",
    "文件操作": "File actions",
    "打开 HTML": "Open HTML",
    "粘贴代码": "Paste code",
    "预览": "Preview",
    "修改": "Edit",
    "修改与预览模式": "Edit and Preview modes",
    "交互预览": "Interactive preview",
    "实时兼容模式": "Live Compatibility Mode",
    "联网兼容模式": "Online Compatibility Mode",
    "开启实时兼容模式": "Enable Live Compatibility Mode",
    "关闭实时兼容模式": "Disable Live Compatibility Mode",
    "开启联网兼容模式": "Enable Online Compatibility Mode",
    "关闭联网兼容模式": "Disable Online Compatibility Mode",
    "已开启": "On",
    "已关闭": "Off",
    "实时兼容画布": "Live Compatibility canvas",
    "实时兼容 HTML 画布": "Live Compatibility HTML canvas",
    "实时属性": "Live properties",
    "直接修改脚本运行后的当前页面": "Edit the current script-rendered page directly",
    "正在准备实时脚本页面…": "Preparing the live scripted page…",
    "正在准备联网脚本页面…": "Preparing the online scripted page…",
    "脚本与编辑器保持隔离": "Scripts remain isolated from the editor",
    "允许网络资源，脚本与编辑器保持隔离": "Network resources are allowed while scripts remain isolated from the editor",
    "文字与排版": "Text and layout",
    "填充、边框与尺寸": "Fill, border, and size",
    "脚本持续运行。若脚本反复重建元素，刚修改的内容可能被页面自身覆盖。": "Scripts keep running. If the page repeatedly rebuilds an element, its own script may overwrite your edit.",
    "图片宽度百分比": "Image width percentage",
    "图片宽度快捷选项": "Image width presets",
    "拖动调整图片大小": "Drag to resize image",
    "例如 12px 16px": "For example, 12px 16px",
    "例如 0 0 16px": "For example, 0 0 16px",
    "脚本已在隔离预览中运行": "Scripts are running in the isolated preview",
    "重试同步": "Retry sync",
    "放弃预览变化并返回": "Discard preview changes and return",
    "交互 HTML 预览": "Interactive HTML preview",
    "保存并覆盖当前文件": "Save and overwrite current file",
    "导出 HTML": "Export HTML",
    "打印为 PDF": "Print to PDF",
    "更多操作": "More actions",
    "工具设置": "Tool settings",
    "用户指南": "User Guide",
    "下载离线包": "Download Offline Package",
    "反馈与建议": "Feedback & Suggestions",
    "更新日志": "Changelog",
    "切换中英文": "Switch Chinese / English",
    "切换到英文": "Switch to English",
    "L4TF 节能模式": "L4TF energy-saving mode",
    "开启 L4TF 节能模式": "Enable L4TF energy-saving mode",
    "关闭 L4TF 节能模式": "Disable L4TF energy-saving mode",
    "编辑操作": "Editing actions",
    "收起图层": "Collapse layers",
    "展开图层": "Expand layers",
    "撤销": "Undo",
    "重做": "Redo",
    "在选中位置插入图片": "Insert image at selection",
    "插入内容": "Insert content",
    "选中元素操作": "Selected element actions",
    "复制选中元素": "Duplicate selected element",
    "上移元素": "Move element up",
    "下移元素": "Move element down",
    "删除选中元素": "Delete selected element",
    "文字快捷格式": "Quick text formatting",
    "粗体": "Bold",
    "左对齐": "Align left",
    "居中": "Center",
    "右对齐": "Align right",
    "查看兼容性提示": "View compatibility notes",
    "画布尺寸": "Canvas size",
    "画布视图": "Canvas view",
    "桌面 1440 x 900": "Desktop 1440 x 900",
    "平板 768 x 1024": "Tablet 768 x 1024",
    "手机 390 x 844": "Mobile 390 x 844",
    "自定义尺寸": "Custom size",
    "页面宽度": "Page width",
    "页面高度": "Page height",
    "显示比例": "Zoom",
    "显示比例百分比": "Zoom percentage",
    "缩小": "Zoom out",
    "放大": "Zoom in",
    "实际大小 (100%)": "Actual size (100%)",
    "适合窗口": "Fit to window",
    "适应窗口": "Fit window",
    "16:9 画布": "16:9 canvas",
    "页面结构": "Page structure",
    "图层": "Layers",
    "运行时页面图层": "Runtime page layers",
    "拖动图层可调整元素顺序": "Drag layers to reorder elements",
    "点击图层可选择元素；使用上移或下移调整顺序": "Click a layer to select it; use Move up or Move down to reorder",
    "正在读取脚本运行后的页面图层…": "Reading layers from the running scripted page…",
    "HTML 编辑画布": "HTML editing canvas",
    "从你的 HTML 开始": "Start with your HTML",
    "选择一个本机 HTML 文件，或粘贴完整代码。": "Choose a local HTML file or paste the complete code.",
    "选择 HTML 文件": "Choose HTML File",
    "粘贴 HTML 代码": "Paste HTML Code",
    "文件仅在本机浏览器中处理": "Files are processed only in your browser",
    "松开以打开 HTML": "Drop to open HTML",
    "原文件不会被覆盖": "The original file will not be overwritten",
    "点击元素开始编辑": "Click an element to start editing",
    "单击选择元素，双击文字可直接修改": "Click to select an element; double-click text to edit directly",
    "单击选择，双击文字直接修改；使用图层或上下移动调整顺序": "Click to select and double-click text to edit; use Layers or Move up/down to reorder",
    "选择或粘贴 HTML 后开始编辑": "Choose or paste HTML to start editing",
    "所有内容仅在本机处理": "Everything stays on this computer",
    "样式与属性": "Styles and properties",
    "样式": "Styles",
    "完整样式属性": "Full style properties",
    "文字内容": "Text content",
    "只修改文字，不会删除图标或按钮功能": "Edit text without removing icons or button actions",
    "此元素包含多处文字，可分别修改。": "This element contains multiple text items. Edit each one separately.",
    "按钮文字": "Button label",
    "当前值": "Current value",
    "占位文字": "Placeholder text",
    "文字修改已应用": "Text change applied",
    "下拉选项": "Select options",
    "自定义下拉选项": "Custom dropdown options",
    "增加、删除或修改每个选项": "Add, remove, or edit each option",
    "同步修改显示文字与实际值": "Edit display labels and stored values together",
    "当前下拉框没有选项": "This select has no options",
    "当前自定义下拉框没有静态选项": "This custom dropdown has no static options",
    "这个容器可能由 JavaScript 生成。新增静态选项后，请在最终预览中确认脚本没有重新覆盖。": "This container may be generated by JavaScript. After adding static options, confirm in the final preview that the script does not overwrite them.",
    "这个容器可能由 JavaScript 生成。修改后请在预览中确认页面脚本没有重新覆盖。": "This container may be generated by JavaScript. After editing it, confirm in Preview that the page script does not overwrite the changes.",
    "增加选项": "Add option",
    "减少选项": "Remove option",
    "显示文字": "Display label",
    "值": "Value",
    "图片": "Image",
    "图片会自动内嵌到 HTML": "Images are embedded into the HTML automatically",
    "拖动图片右下角可自由缩放，也可使用下方宽度选项": "Drag the image's bottom-right handle to resize freely, or use the width controls below",
    "拖动图片角点可自由缩放，也可使用下方宽度选项": "Drag an image corner to resize freely, or use the width controls below",
    "替换图片": "Replace image",
    "图片宽度": "Image width",
    "Canvas 图表": "Canvas chart",
    "可调整整体尺寸，数据无法反向编辑": "You can resize it, but its data cannot be edited",
    "选择一个元素": "Select an element",
    "右侧将显示可以修改的样式": "Editable styles will appear on the right",
    "粘贴完整 HTML": "Paste complete HTML",
    "从公司 AI 复制完整代码并粘贴到这里": "Paste the complete code generated by your company AI here",
    "取消": "Cancel",
    "载入编辑器": "Load into editor",
    "最终效果预览": "Final preview",
    "重新载入预览": "Reload preview",
    "关闭": "Close",
    "导出 HTML 预览": "Export HTML preview",
    "预览与编辑器隔离，页面脚本与网络依赖可运行": "Preview is isolated from the editor while page scripts and network dependencies can run",
    "兼容性检查": "Compatibility check",
    "这些提示不会阻止编辑。请在导出前通过“预览”检查最终效果。": "These notes do not block editing. Check the final result in Preview before exporting.",
    "继续导出": "Continue export",
    "放弃未导出的修改？": "Discard unsaved changes?",
    "打开其他 HTML 会清空当前修改。": "Opening another HTML file will clear the current changes.",
    "继续编辑": "Keep editing",
    "放弃并继续": "Discard and continue",
    "当前版本": "Current",
    "双语图文指南更新": "Bilingual Visual Guide Update",
    "新增完整的中英双语用户指南，覆盖全部编辑、保存、导出及离线使用流程。": "Added a complete bilingual user guide covering editing, saving, exporting, and offline use.",
    "指南使用脱敏合成报告的真实界面截图，支持全文搜索、章节定位、阅读进度和打印 PDF。": "The guide uses real interface screenshots with sanitized synthetic content and supports full-text search, section navigation, reading progress, and PDF printing.",
    "文件夹版与单文件版均可离线打开指南，并自动沿用 Beauty Lab 当前语言。": "Both folder and standalone editions open the guide offline and automatically carry over the current Beauty Lab language.",
    "L4TF 首页显示修复": "L4TF Home Screen Display Fix",
    "修复未载入 HTML 时欢迎画布仍为白色的问题，节能模式现在覆盖整个工作区。": "Fixed the welcome canvas remaining white before an HTML file is loaded; energy-saving mode now covers the entire workspace.",
    "补齐首页标题、说明文字、状态栏和辅助信息的深色主题对比度。": "Improved dark-theme contrast for the home title, instructions, status bar, and supporting information.",
    "主页菜单与文件名更新": "Home Menu and File Name Update",
    "修复未载入 HTML 时“更多操作”菜单被主页欢迎层遮挡的问题。": "Fixed the More actions menu being covered by the welcome screen before an HTML file is loaded.",
    "粘贴代码后可点击顶部文件名修改导出名称，并自动补全 .html 扩展名。": "After pasting code, click the file name in the top bar to rename the export; the .html extension is added automatically.",
    "紧凑工具栏更新": "Compact Toolbar Update",
    "采用更简洁的顶栏布局，缩小按钮文字、图标和操作占位。": "Introduced a cleaner top bar with smaller labels, icons, and action footprints.",
    "打开、粘贴、语言切换和 L4TF 节能模式保持在顶栏直接可见。": "Kept Open, Paste, language switching, and L4TF energy-saving mode directly visible in the top bar.",
    "打印、反馈与建议和更新日志统一收纳到“更多操作”菜单。": "Moved Print, Feedback & Suggestions, and Changelog into the More actions menu.",
    "动态图表与办公辅助更新": "Dynamic Charts and Office Utilities",
    "修复内联背景色丢失，testing5 的图例色块可正常显示。": "Preserved inline background colors so testing5 legend swatches display correctly.",
    "新增安全运行时快照，D2C Return Analysis 的 2025 Full Year 等脚本图表可在编辑画布显示。": "Added safe runtime snapshots so scripted charts such as D2C Return Analysis 2025 Full Year appear on the editing canvas.",
    "用户修改过的下拉选项会在原页面脚本执行后恢复，新增、删除和改值可保留到预览与导出。": "Edited select options are restored after the original page scripts run, preserving additions, deletions, and value changes in preview and export.",
    "反馈图标固定打开团队 Microsoft Forms，分享工具后无需再次配置。": "The feedback icon now opens the team Microsoft Forms directly, with no setup needed after sharing the tool.",
    "语言按钮在中文界面显示 EN，在英文界面显示 CN；保留 L4TF 黑色节能模式。": "The language button shows EN in the Chinese interface and CN in the English interface; L4TF black energy-saving mode remains available.",
    "高效编辑更新": "Editing Productivity Update",
    "新增原生及自定义下拉选项编辑。": "Added native and custom dropdown option editing.",
    "新增图片插入、替换和尺寸调整。": "Added image insertion, replacement, and resizing.",
    "新增保存并覆盖当前文件，以及图层栏收起与展开。": "Added save-and-overwrite plus collapsible layers.",
    "交互预览与修改同步": "Interactive Preview and Edit Sync",
    "新增“修改｜预览”双模式，可在预览中运行脚本、点击按钮并切换动态页面。": "Added Edit | Preview modes so scripts can run and users can click buttons or switch dynamic pages in Preview.",
    "返回修改模式时自动捕获当前 DOM、表单与显隐状态，动态页面中的普通内容可继续编辑。": "Returning to Edit automatically captures the current DOM, form values, and visibility state so regular content on dynamic pages remains editable.",
    "导出文件会在原脚本初始化后恢复最后同步的页面状态，同时保留原有按钮交互。": "Exported files restore the last synchronized page state after the original scripts initialize while preserving button interactions.",
    "正在载入交互预览…": "Loading interactive preview...",
    "预览模式": "Preview mode",
    "交互预览尚未准备好。": "The interactive preview is not ready yet.",
    "同步超过 4 秒，请重试。": "Sync exceeded four seconds. Please retry.",
    "正在同步当前预览状态…": "Synchronizing the current preview state...",
    "正在同步预览…": "Synchronizing preview...",
    "预览没有返回可编辑页面内容。": "The preview did not return editable page content.",
    "无法把当前预览转换为可编辑页面。": "The current preview could not be converted into an editable page.",
    "预览状态已同步，可继续修改当前页面": "Preview state synchronized. You can now edit the current page.",
    "预览状态未发生变化": "The preview state did not change",
    "预览同步失败，请重试。": "Preview sync failed. Please retry.",
    "预览同步失败": "Preview sync failed",
    "已放弃本轮预览变化": "Preview changes discarded",
    "重新载入预览？": "Reload preview?",
    "本轮尚未同步的点击、输入和选择变化将被放弃。": "Unsynchronized clicks, input, and selection changes from this preview session will be discarded.",
    "预览中有尚未同步的交互变化": "The preview contains unsynchronized interaction changes",
    "交互预览已就绪，可点击页面按钮": "Interactive preview ready. You can click page buttons.",
    "正在进入实时兼容模式…": "Entering Live Compatibility Mode…",
    "实时预览模式": "Live Preview mode",
    "脚本持续运行，可操作页面中的按钮和筛选器": "Scripts keep running; page buttons and filters are interactive",
    "点击脚本生成的文字、按钮或组件进行修改": "Click script-generated text, buttons, or components to edit them",
    "单击选择，双击文字直接修改；按住 Ctrl/Cmd 点击可运行页面按钮": "Click to select and double-click text to edit; hold Ctrl/Cmd while clicking to run page buttons",
    "正在同步实时页面…": "Synchronizing the live page…",
    "正在读取当前运行时 DOM…": "Reading the current runtime DOM…",
    "实时页面同步超过 4 秒，请重试。": "Live page synchronization exceeded four seconds. Please retry.",
    "实时页面没有返回可编辑内容。": "The live page did not return editable content.",
    "无法读取当前实时页面。": "The current live page could not be read.",
    "当前实时页面已同步，可继续修改": "The current live page is synchronized and ready for editing",
    "实时页面同步失败。": "Live page synchronization failed.",
    "实时页面同步失败": "Live page synchronization failed",
    "同步失败，请稍后重试或关闭实时兼容模式": "Synchronization failed. Retry later or disable Live Compatibility Mode",
    "实时页面尚未完成同步，请稍后重试。": "The live page is not synchronized yet. Please retry shortly.",
    "无法准备实时页面。": "The live page could not be prepared.",
    "已进入实时兼容模式，脚本将在隔离画布中持续运行": "Live Compatibility Mode enabled. Scripts will keep running in the isolated canvas",
    "已自动进入联网兼容模式，脚本和动效将持续运行": "Online Compatibility Mode enabled automatically. Scripts and animations will keep running",
    "正在联网加载外部资源…": "Loading external resources online…",
    "网络资源加载失败，请检查网络后重新开启兼容模式": "Network resources failed to load. Check your connection, then reopen Compatibility Mode",
    "已自动启用联网兼容画布": "Online Compatibility canvas enabled automatically",
    "页面将联网加载外部资源，并从原始 DOM 持续运行脚本和动效。": "The page will load external resources online and keep scripts and animations running from the original DOM.",
    "页面将从原始 DOM 持续运行脚本和动效，普通文字和样式可直接修改。": "The page will keep scripts and animations running from the original DOM while regular text and styles remain directly editable.",
    "正在联网加载外部资源": "Loading external resources online",
    "个网络资源加载失败，请检查网络后重新开启兼容模式": "network resources failed to load. Check your connection, then reopen Compatibility Mode",
    "实时页面同步失败，仍保留在当前模式。": "Live page synchronization failed. The current mode remains active.",
    "实时页面已同步回标准修改模式": "The live page was synchronized back to Standard Edit mode",
    "修改已应用到当前运行时页面": "The edit was applied to the current runtime page",
    "交互状态已保留，切回修改不会重建页面": "Interaction state is preserved; returning to Edit will not rebuild the page",
    "实时页面操作失败。": "The live page operation failed.",
    "预览变化待同步": "Preview changes pending sync",
    "已撤销整次预览同步": "Reverted the entire preview sync",
    "已恢复整次预览同步": "Restored the entire preview sync",
    "文字": "Typography",
    "按钮": "Button",
    "标签": "Label",
    "折叠标题": "Summary",
    "图注": "Caption",
    "表格单元格": "Table cell",
    "表头单元格": "Table header cell",
    "输入框": "Input",
    "文本框": "Text area",
    "链接": "Link",
    "元素": "Element",
    "已是默认项": "Current default",
    "字体": "Font",
    "微软雅黑": "Microsoft YaHei",
    "宋体": "SimSun",
    "楷体": "KaiTi",
    "字号": "Font size",
    "字重": "Weight",
    "常规": "Regular",
    "中等": "Medium",
    "半粗": "Semi-bold",
    "行高": "Line height",
    "字间距": "Letter spacing",
    "文字颜色": "Text color",
    "对齐": "Alignment",
    "左": "Left",
    "中": "Center",
    "右": "Right",
    "两端": "Justify",
    "填充与边框": "Fill and border",
    "背景色": "Background color",
    "透明度": "Opacity",
    "边框宽度": "Border width",
    "边框样式": "Border style",
    "无": "None",
    "实线": "Solid",
    "虚线": "Dashed",
    "点线": "Dotted",
    "边框颜色": "Border color",
    "圆角": "Corner radius",
    "尺寸": "Size",
    "宽度": "Width",
    "高度": "Height",
    "最小宽度": "Minimum width",
    "最小高度": "Minimum height",
    "最大宽度": "Maximum width",
    "间距": "Spacing",
    "外边距": "Margin",
    "内边距": "Padding",
    "上": "Top",
    "下": "Bottom",
    "布局（高级）": "Layout (advanced)",
    "显示方式": "Display",
    "块": "Block",
    "行内块": "Inline block",
    "弹性布局": "Flex",
    "网格": "Grid",
    "隐藏": "Hidden",
    "排列方向": "Direction",
    "横向": "Row",
    "纵向": "Column",
    "主轴对齐": "Main-axis alignment",
    "交叉轴对齐": "Cross-axis alignment",
    "起点": "Start",
    "终点": "End",
    "拉伸": "Stretch",
    "元素间距": "Gap",
    "页面": "Page",
    "分区": "Section",
    "主体": "Main",
    "容器": "Container",
    "一级标题": "Heading 1",
    "二级标题": "Heading 2",
    "三级标题": "Heading 3",
    "段落": "Paragraph",
    "SVG 图形": "SVG graphic",
    "列表": "List",
    "编号列表": "Numbered list",
    "列表项": "List item",
    "下拉框": "Select",
    "自定义下拉框": "Custom dropdown",
    "表格": "Table",
    "兼容性良好": "Compatibility looks good",
    "未发现明显兼容性风险": "No obvious compatibility risks found",
    "原脚本和内联事件会在预览及导出文件中恢复。依赖原始 DOM 结构的脚本需要重点检查。": "Original scripts and inline events are restored in preview and export. Scripts that depend on the original DOM structure need extra review.",
    "页面脚本会在隔离环境中运行，运行后的 DOM 和样式将转换为可编辑副本；原脚本仍会在预览和导出文件中运行。": "Page scripts run in an isolated environment, and the resulting DOM and styles are converted into an editable copy. Original scripts still run in preview and exported files.",
    "iframe、object 和 embed 在编辑时不会载入，预览及导出时恢复。": "iframe, object, and embed content is paused while editing and restored in preview and export.",
    "Canvas 内的文字和图表数据无法反向编辑，只能调整元素整体尺寸并在预览中检查脚本渲染结果。": "Text and chart data inside Canvas cannot be edited. Resize the whole element and check script rendering in preview.",
    "简单 SVG 可以整体调整；复杂路径建议保留原结构，不要拆分图层。": "Simple SVG graphics can be resized as a whole. Keep complex paths intact rather than splitting their layers.",
    "导入和预览会尝试加载网络脚本、样式、字体和图片；断网使用前仍应将这些资源内嵌到 HTML。": "Import and preview try to load network scripts, styles, fonts, and images. Embed these resources before using the page offline.",
    "React、Vue 或脚本动态生成的内容无法保证无损回写；请以最终预览为准。": "React, Vue, and script-generated content cannot be guaranteed to round-trip without changes. Use the final preview as the reference.",
    "页面不包含脚本、外部资源或 Canvas。仍建议在导出前检查一次最终预览。": "The page contains no scripts, external resources, or Canvas. A final preview check is still recommended before export.",
    "图表和动态内容以隔离沙箱中的静态快照载入；原脚本仍只在最终预览和导出文件中运行。": "Charts and dynamic content are loaded as static snapshots from an isolated sandbox. Original scripts still run only in final preview and exported files.",
    "已载入脚本运行后的可编辑页面": "Loaded an editable page from the script runtime",
    "普通 DOM 文字、图片和样式可以继续修改；Canvas、Shadow DOM 及脚本反复重建的内容仍需在最终预览中检查。": "Regular DOM text, images, and styles remain editable. Canvas, Shadow DOM, and content repeatedly rebuilt by scripts still need to be checked in the final preview.",
    "页面脚本未在限定时间内完成": "Page scripts did not finish within the time limit",
    "编辑器已载入原始 DOM。请检查网络依赖，或在最终预览中确认需要较长时间初始化的内容。": "The editor loaded the original DOM. Check network dependencies or use the final preview for content that needs more time to initialize.",
    "页面可能包含运行时框架代码": "The page may contain runtime framework code",
    "请先载入 HTML": "Load HTML first",
    "有未保存修改": "Unsaved changes",
    "已载入": "Loaded",
    "已保存": "Saved",
    "自动": "Auto",
    "上移选项": "Move option up",
    "下移选项": "Move option down",
    "复制选项": "Duplicate option",
    "删除选项": "Delete option",
    "设为默认项": "Set as default",
    "取消默认项": "Clear default",
    "设为默认勾选": "Set as checked by default",
    "取消默认勾选": "Clear default checked state",
    "已增加一个选项": "Option added",
    "选项已删除": "Option deleted",
    "选项已复制": "Option duplicated",
    "选项已上移": "Option moved up",
    "选项已下移": "Option moved down",
    "已设置默认选项": "Default option set",
    "已取消默认选项": "Default option cleared",
  };

  const patterns = [
    [/^Canvas (\d+) 无法转为图片$/, (_, count) => `Canvas ${count} cannot be captured as an image`],
    [/^(\d+) 个嵌入页面或对象无法转为图片$/, (_, count) => `${count} embedded pages or objects cannot be captured as images`],
    [/^文字 (\d+)$/, (_, count) => `Text ${count}`],
    [/^(\d+) 处$/, (_, count) => `${count} text items`],
    [/^(\d+) 项$/, (_, count) => `${count} items`],
    [/^(\d+) 项需要检查$/, (_, count) => `${count} items to check`],
    [/^预览前请留意 (\d+) 项兼容性提示$/, (_, count) => `Review ${count} compatibility notes before preview`],
    [/^预览已就绪，请留意 (\d+) 项兼容性提示$/, (_, count) => `Preview ready. Review ${count} compatibility notes`],
    [/^已显示 (\d+) 个脚本生成区域$/, (_, count) => `Displayed ${count} script-generated regions`],
    [/^检测到 (\d+) 项脚本行为$/, (_, count) => `Detected ${count} scripted behaviors`],
    [/^已暂停 (\d+) 个嵌入页面或对象$/, (_, count) => `Paused ${count} embedded pages or objects`],
    [/^检测到 (\d+) 个 Canvas 元素$/, (_, count) => `Detected ${count} Canvas elements`],
    [/^检测到 (\d+) 个 SVG 图形$/, (_, count) => `Detected ${count} SVG graphics`],
    [/^检测到 (\d+) 个网络资源$/, (_, count) => `Detected ${count} network resources`],
    [/^已载入 (.+)$/, (_, name) => `Loaded ${name}`],
    [/^已生成 (.+)$/, (_, name) => `Created ${name}`],
    [/^已保存并覆盖 (.+)$/, (_, name) => `Saved and overwrote ${name}`],
    [/^导出文件名已改为 (.+)$/, (_, name) => `Export file name changed to ${name}`],
    [/^新选项 (\d+)$/, (_, count) => `New option ${count}`],
  ];

  let language = readStoredLanguage();
  const textRecords = new WeakMap();
  const attributeRecords = new WeakMap();
  const listeners = new Set();

  function readStoredLanguage() {
    try {
      return localStorage.getItem(STORAGE_KEY) === "en" ? "en" : "zh";
    } catch {
      return "zh";
    }
  }

  function translateCore(value) {
    if (language !== "en") return value;
    if (Object.prototype.hasOwnProperty.call(english, value)) return english[value];
    for (const [pattern, replacer] of patterns) {
      if (pattern.test(value)) return value.replace(pattern, replacer);
    }
    return value;
  }

  function translate(value) {
    const input = String(value ?? "");
    const match = input.match(/^(\s*)([\s\S]*?)(\s*)$/);
    return `${match[1]}${translateCore(match[2])}${match[3]}`;
  }

  function shouldSkip(node) {
    const element = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
    return Boolean(element?.closest("script, style, iframe, [data-i18n-ignore]"));
  }

  function applyTextNode(node) {
    if (shouldSkip(node) || !node.nodeValue?.trim()) return;
    let record = textRecords.get(node);
    if (!record || node.nodeValue !== record.rendered) record = { source: node.nodeValue, rendered: node.nodeValue };
    const rendered = language === "en" ? translate(record.source) : record.source;
    record.rendered = rendered;
    textRecords.set(node, record);
    if (node.nodeValue !== rendered) node.nodeValue = rendered;
  }

  function applyAttributes(element) {
    if (shouldSkip(element)) return;
    let records = attributeRecords.get(element);
    if (!records) {
      records = new Map();
      attributeRecords.set(element, records);
    }
    ATTRIBUTES.forEach((name) => {
      if (!element.hasAttribute(name)) return;
      const current = element.getAttribute(name);
      let record = records.get(name);
      if (!record || current !== record.rendered) record = { source: current, rendered: current };
      const rendered = language === "en" ? translate(record.source) : record.source;
      record.rendered = rendered;
      records.set(name, record);
      if (current !== rendered) element.setAttribute(name, rendered);
    });
  }

  function apply(root = document.body) {
    if (!root) return;
    if (root.nodeType === Node.TEXT_NODE) {
      applyTextNode(root);
      return;
    }
    if (root.nodeType !== Node.ELEMENT_NODE && root.nodeType !== Node.DOCUMENT_NODE) return;
    if (root.nodeType === Node.ELEMENT_NODE) applyAttributes(root);
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (node.nodeType === Node.TEXT_NODE) applyTextNode(node);
      else applyAttributes(node);
    }
  }

  function setLanguage(nextLanguage) {
    language = nextLanguage === "en" ? "en" : "zh";
    try {
      localStorage.setItem(STORAGE_KEY, language);
    } catch {
      // Language still works for the current session.
    }
    document.documentElement.lang = language === "en" ? "en" : "zh-CN";
    apply(document.body);
    listeners.forEach((listener) => listener(language));
  }

  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.type === "characterData") applyTextNode(mutation.target);
      if (mutation.type === "attributes") applyAttributes(mutation.target);
      mutation.addedNodes?.forEach((node) => apply(node));
    });
  });

  if (document.body) {
    apply(document.body);
    observer.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRIBUTES });
  }

  global.BeautyLabI18n = Object.freeze({
    getLanguage: () => language,
    onChange(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    refresh: () => apply(document.body),
    setLanguage,
    t: translate,
  });
})(window);
